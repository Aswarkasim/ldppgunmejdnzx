@include('home/layouts/head')
@include('home/layouts/header')
@include('home/layouts/content')
@include('home/layouts/footer')