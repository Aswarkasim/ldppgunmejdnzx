<div class="row">
  <div class="col-md-6">
    <div class="p-3  card">
      <div class="card-body">


          <form action="/admin/konfigurasi/update" method="POST">  
            <?php echo method_field('PUT'); ?>
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="">Nama Aplikasi</label>
            <input type="text" class="form-control  <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="app_name"  value="<?php echo e(isset($konfigurasi) ? $konfigurasi->app_name : old('app_name')); ?>" placeholder="Nama">
             <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

       

          <a href="/admin/konfigurasi" class="btn btn-info "><i class="fa fa-arrow-left"></i> Kembali</a>
         <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
        
        </form>
      </div>
    </div>
  </div>
</div>

<?php /**PATH E:\Laravel\lr-fw-ktc\resources\views/admin/konfigurasi/index.blade.php ENDPATH**/ ?>