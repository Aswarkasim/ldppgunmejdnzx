<div class="row">
  <div class="col-md-6">
    <div class="p-3  card">
      <div class="card-body">

        <?php if(Request::is('admin/posts/kategori/create')): ?>
          <form action="/admin/posts/kategori" method="POST">  
        <?php else: ?>
          <form action="/admin/posts/kategori/<?php echo e($kategori->id); ?>" method="POST">  
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="">Nama</label>
            <input type="text" class="form-control  <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="nama"  value="<?php echo e(isset($kategori) ? $kategori->nama : old('nama')); ?>" placeholder="Nama">
             <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                  <?php echo e($message); ?>

                </div>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

     

          <a href="/admin/posts/kategori" class="btn btn-info "><i class="fa fa-arrow-left"></i> Kembali</a>
         <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
        
        </form>
      </div>
    </div>
  </div>
</div>

<?php /**PATH E:\Laravel\lr-fw-ktc\resources\views/admin/kategori/add.blade.php ENDPATH**/ ?>