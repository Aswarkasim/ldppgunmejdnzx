<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
 
  <?php if(isset($content)): ?>
  <?php echo $__env->make($content, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <?php else: ?>
  <?php echo e('Tidak ada halaman'); ?>

  <?php endif; ?>
  
<?php /**PATH E:\Laravel\ldppgunm\resources\views/home/layouts/content.blade.php ENDPATH**/ ?>