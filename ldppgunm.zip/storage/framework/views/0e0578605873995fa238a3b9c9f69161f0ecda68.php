
<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li data-target="#myCarousel" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($item->urutan == '1' ? 'active' : ''); ?>"></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ol>
  <div class="carousel-inner">

    <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="carousel-item <?php echo e($item->urutan == '1' ? 'active' : ''); ?>">
      <img class="first-slide" src="<?php echo e($item->image); ?>" alt="First slide">
      <div class="container">
        <div class="carousel-caption text-left">
          <h1><?php echo e($item->topik); ?></h1>
          <p><?php echo e($item->desc); ?></p>
          <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<div class="container">
  <div class="row">
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-3 overflow-hidden">
      <div class="rounded shadow-sm p-0">
        <div class="img-post-wrapper">
          <img src="/<?php echo e($item->image); ?>" class="img-post" alt="">
        </div>
        <div class="p-2">
          <a href="/home/post/show/<?php echo e($item->slug); ?>"><h5><strong><?php echo e($item->title); ?></strong></h5></a>
          <><?php echo $item->excerpt; ?> <a href="">Baca Selengkapnya &rightarrow;</a></p>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
  </div>
</div>

<?php /**PATH E:\Laravel\ldppgunm\resources\views/home/home/index.blade.php ENDPATH**/ ?>